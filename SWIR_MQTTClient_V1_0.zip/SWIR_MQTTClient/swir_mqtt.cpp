/*******************************************************************************
 * MQTT class for Sierra Wireless' HL Serie Modules
 * wrapping a simple MQTT Client and a TCP AT-Command layer (exposing same interface as Arduino's Client/EthernetClient)
 *
 * Nhon Chu - April 2017 - V1.00
 *******************************************************************************/

#include "swir_mqtt.h"

#include "swir_debug.h"

#include <stdlib.h>
#include <ctype.h>
 
#define 	TOPIC_NAME_PUBLISH			"/messages/json"
#define 	TOPIC_NAME_SUBSCRIBE		"/tasks/json"
#define		TOPIC_NAME_ACKCMD			"/acks/json"
#define 	URL_AIRVANTAGE_SERVER		"eu.airvantage.net"
#define 	PORT_AIRVANTAGE_SERVER		1883

#define		MAX_SIZE_128				128
#define		MAX_SIZE_256				256

#define		AV_JSON_KEY_MAX_COUNT		10		//max number of Key in AV-MQTT JSON payload
#define		AV_JSON_KEY_MAX_LENGTH		32		//default max length of Key Name


SWIR_MQTTClient::inMessageHandler SWIR_MQTTClient::_pfnInMsgCallback = NULL;
SWIR_MQTTClient* SWIR_MQTTClient::_pThisClient = NULL;

SWIR_MQTTClient::SWIR_MQTTClient(MODULE_SERIAL_CLASS& module)
{
	_pMqttClient = new PubSubClient(URL_AIRVANTAGE_SERVER, PORT_AIRVANTAGE_SERVER, incomingMessageHandler, _swirModule);
	SWIR_MQTTClient::_pfnInMsgCallback = NULL;

	//_ePublishQoS = MQTT::QOS0;

	_pszPublishTopic = NULL;
	_pszIdentifier = NULL;

	_swirModule.setSerialObject(module);
}

void SWIR_MQTTClient::setBaudRate(
		long 			nBaudrate)
{
	_swirModule.setBaudRate(nBaudrate);
}

int SWIR_MQTTClient::setSimPIN(int nPinCode)
{
	#ifdef _VERBOSE_DEBUG_
	SWIR_TRACE(F("MQTTClient::setSimPIN"));
	#endif
	return _swirModule.setSimPIN(nPinCode);
}

int SWIR_MQTTClient::isSimReady()
{
	return _swirModule.isSimReady();
}

int SWIR_MQTTClient::setAPN(char* szAPN, char* szAPNlogin, char * szAPNpassword)
{
	if ( (szAPNlogin == NULL) && (szAPNpassword == NULL) )
	{
		return _swirModule.setAPN(szAPN, "", "");
	}
	else if (szAPNlogin == NULL)
	{
		return _swirModule.setAPN(szAPN, "", szAPNpassword);
	}
	else if (szAPNpassword == NULL)
	{
		return _swirModule.setAPN(szAPN, szAPNlogin, "");
	}
	else
	{
		return _swirModule.setAPN(szAPN, szAPNlogin, szAPNpassword);
	}
}

int SWIR_MQTTClient::connect(char* szIdentifier, char* szPassword, uint16_t uiKeepAlive)
{
	if (!_swirModule.canConnect())
	{
		return 3;
	}

	SWIR_TRACE(F("\r\n---- MQTT Connecting ----\r\n"));
	if (_pMqttClient->connect(szIdentifier, szIdentifier, szPassword, uiKeepAlive))
	{
		if (_pszIdentifier)
		{
			free(_pszIdentifier);
		}
		_pszIdentifier = (char *) malloc(strlen(szIdentifier) + 1);
		strcpy(_pszIdentifier, szIdentifier);

		if (_pszPublishTopic)
		{
			free(_pszPublishTopic);
		}
		_pszPublishTopic = (char *) malloc(strlen(_pszIdentifier) + strlen(TOPIC_NAME_PUBLISH) + 1);
		sprintf(_pszPublishTopic, "%s%s", _pszIdentifier, TOPIC_NAME_PUBLISH);
		
		SWIR_AVAILABLE_SRAM

		SWIR_TRACE(F("\r\n---- MQTT Connected ----\r\n"));

        return 0;
    }
    else
    {
    	SWIR_TRACE(F("\r\n---- FAIL MQTT Connect ----"));

		return 1;
    }

}

int SWIR_MQTTClient::connect(char* szPassword, uint16_t uiKeepAlive)
{
	if (!_swirModule.canConnect())
	{
		return 3;
	}

	char  szIMEI[16];
	char  szSN[32];
	char  szModuleType[16];

	_swirModule.getSN(szSN, sizeof(szSN));
	_swirModule.getModuleType(szModuleType, sizeof(szModuleType));

	if (_swirModule.getIMEI(szIMEI, sizeof(szIMEI)) != 0)
	{
		SWIR_TRACE(F("Failed to retrieve IMEI: %s"), szIMEI);
		return 2;
	}
	
	if (connect(szIMEI, szPassword, uiKeepAlive))
	{
		SWIR_TRACE(F("Please register your module on AirVantage portal or Check the Password:"));
		SWIR_TRACE(F("Module Type: %s"), szModuleType);
		SWIR_TRACE(F("Serial Number: %s"), szSN);
		SWIR_TRACE(F("IMEI: %s\r\n"), szIMEI);

		return 1;
	}

	return 0;
}


int SWIR_MQTTClient::isConnected()
{
	SWIR_AVAILABLE_SRAM
	return _pMqttClient->connected();
}

int SWIR_MQTTClient::isDataCallReady()
{
	return _swirModule.canConnect();
}

void SWIR_MQTTClient::disconnect()
{
	if (_pMqttClient != NULL)
	{
		_pMqttClient->disconnect();
	}
	if (_pszIdentifier)
	{
		free(_pszIdentifier);
		_pszIdentifier = NULL;
	}
	if (_pszPublishTopic)
	{
		free(_pszPublishTopic);
		_pszPublishTopic = NULL;
	}
}

void SWIR_MQTTClient::loop()
{
	if (_pMqttClient != NULL)
	{
		_pMqttClient->loop();
	}
}

#if 0
void	SWIR_MQTTClient::setPublishQos(int nQoS)
{
	SWIR_AVAILABLE_SRAM

	switch (nQoS)
	{
		case 1:
			_ePublishQoS = MQTT::QOS1;
			break;
		case 2:
			_ePublishQoS = MQTT::QOS2;
			break;
		default:
			_ePublishQoS = MQTT::QOS0;
			break;
	}
}
#endif

int SWIR_MQTTClient::publishAckCmd(const char* szUid, int nAck, char* szMessage)
{
	int rc = 1;

	char* szPayload = (char*) malloc(strlen(szUid)+strlen(szMessage)+48);
	memset(szPayload, 0, strlen(szUid)+strlen(szMessage)+48);

	if (nAck == 0)
	{
		sprintf(szPayload, "[{\"uid\": \"%s\", \"status\" : \"OK\"", szUid);
	}
	else
	{
		sprintf(szPayload, "[{\"uid\": \"%s\", \"status\" : \"ERROR\"", szUid);
	}

	if (strlen(szMessage) > 0)
	{
		sprintf(szPayload, "%s, \"message\" : \"%s\"}]", szPayload, szMessage);
	}
	else
	{
		sprintf(szPayload, "%s}]", szPayload);
	}
	
	char*	pszAckTopic = (char *) malloc(strlen(_pszIdentifier) + strlen(TOPIC_NAME_ACKCMD) + 1);
	sprintf(pszAckTopic, "%s%s", _pszIdentifier, TOPIC_NAME_ACKCMD);

#ifdef _SWIR_OUTPUT_
	SWIR_TRACE(F("\r\nPublishing: Ack(%d) to %s"), nAck, pszAckTopic);
	SWIR_TRACE(F("  Ack payload: %s"), szPayload);
#endif
	
    if (_pMqttClient->publish(pszAckTopic, szPayload))
    {
    	SWIR_TRACE(F("MQTT publish OK\r\n"));
    	rc = 0;
    }
    else
    {
    	SWIR_TRACE(F("FAILED MQTT publish\r\n"));	
    	rc = 1;
    }
    
	if (szPayload)
	{
		free(szPayload);
	}
	if (pszAckTopic)
	{
		free(pszAckTopic);
	}

	return rc;
}


int SWIR_MQTTClient::publish(char* szKey, char* szValue)
{
	int rc = 1;

#ifdef _SWIR_OUTPUT_
	//SWIR_TRACE(F("\r\nPublishing: %s=%s to %s"), szKey, szValue, _pszPublishTopic);
	SWIR_TRACE(F("\r\nPublishing: %s=%s"), szKey, szValue);
#endif

	if (strlen(_pszPublishTopic) > 0)
	{
		char* payload = (char *) malloc(strlen(szKey)+strlen(szValue)+12);

		sprintf(payload, "{\"%s\":\"%s\"}", szKey, szValue);
        //SWIR_TRACE(F("postString= %s"), payload);
        if (_pMqttClient->publish(_pszPublishTopic, payload))
        {
        	rc = 0;
        }
        free(payload);
	}

	if (rc == 0)
    {
    	SWIR_TRACE(F("MQTT publish OK\r\n"));
    }
    else
    {
    	SWIR_TRACE(F("FAILED MQTT publish\r\n"));
    }

	return rc;
}

int SWIR_MQTTClient::publish(char* szKey, double dValue)
{
	char szValue[16];

#ifdef TARGET_ARDUINO
	dtostrf(dValue, 8, 2, szValue);
#endif
#ifdef TARGET_MBED
	sprintf(szValue, "%.2f", dValue);
#endif
	return publish(szKey, szValue);
}

int SWIR_MQTTClient::publish(char* szKey, int nValue)
{
	char szValue[8];

	sprintf(szValue, "%d", nValue);

	return publish(szKey, szValue);
}

int SWIR_MQTTClient::publish(char* szKey, unsigned long ulValue)
{
	char szValue[16];

	sprintf(szValue, "%lu", ulValue);

	return publish(szKey, szValue);
}

void SWIR_MQTTClient::incomingMessageHandler(char* topic, char* payload, uint16_t length)
{
	payload[length] = 0;

#ifdef _SWIR_OUTPUT_
	SWIR_TRACE(F("Received MQTT- topic:%s :  %s"), topic, payload);
#endif

	//ACK the incoming command
	char*	pszUid = getJsonValue(payload, -1, "uid");
	
	if (_pfnInMsgCallback != NULL)
	{
		//decode JSON payload
		char* pszCommand = getJsonValue(payload, -1, "command");
		if (pszCommand)
		{
			char*	pszTimestamp = getJsonValue(payload, -1, "timestamp");
			char*	pszId = getJsonValue(pszCommand, -1, "id");
			char*	pszParam = getJsonValue(pszCommand, -1, "params");

			//char	szErrorMessage[MAX_SIZE_128];
			
			//szErrorMessage[0] = 0;	//empty string

			if (pszUid)
			{
				_pThisClient->publishAckCmd(pszUid, 0, "");		//for now, must always returns OK
				free(pszUid);
				pszUid = NULL;
			}
			
			for (int i=0; i<AV_JSON_KEY_MAX_COUNT; i++)
			{
				char szKey[AV_JSON_KEY_MAX_LENGTH];

				char * pszValue = getJsonValue(pszParam, i, szKey);

				if (pszValue)
				{
					/*int nRet = */ handleCallback(pszId, szKey, pszValue, pszTimestamp);	

					#if 0
					if (nRet != 0)
					{
						sprintf(szErrorMessage, "%s - %s unknown", szErrorMessage, szKey);
						nAck = nRet;
					}
					#endif

					free(pszValue);
				}
				else
				{
					break;
				}
			}

			free(pszCommand);
			if (pszId)
			{
				free(pszId);
			}
			if (pszParam)
			{
				free(pszParam);
			}
			if (pszTimestamp)
			{
				free(pszTimestamp);
			}
		}
	}
	else
	{
		SWIR_TRACE(F("User callback not provided"));
	}

	if (pszUid)
	{
		_pThisClient->publishAckCmd(pszUid, 0, "");		//for now, must always returns OK
		free(pszUid);
	}

#ifdef _SWIR_OUTPUT_
	SWIR_TRACE(F("MQTT in-msg decoded"));
#endif
}

int SWIR_MQTTClient::handleCallback(char* szPath, char* szKey, char* szValue, char* szTimestamp)
{
	/*
	This function converts the provided JSON-decoded data (from MQTT payload) to CSV data (key;value;timestamp)
	*/

	if (_pfnInMsgCallback == NULL)
	{
		return 1;
	}

	if (!szPath || !szKey || !szValue /* || !szTimestamp*/)
	{
		return 1;
	}
	
	char	szKeyName[MAX_SIZE_128];

	sprintf(szKeyName, "%s.%s", szPath, szKey);

	return SWIR_MQTTClient::_pfnInMsgCallback(szKeyName, szValue, szTimestamp);
}

int SWIR_MQTTClient::subscribe(inMessageHandler pfnCallback)
{
	int rc = 1;

	char*	pszSubscribeTopic = (char *) malloc(strlen(_pszIdentifier) + strlen(TOPIC_NAME_SUBSCRIBE) + 1);
	sprintf(pszSubscribeTopic, "%s%s", _pszIdentifier, TOPIC_NAME_SUBSCRIBE);

	SWIR_TRACE(F("Subscribing to topic: %s"), pszSubscribeTopic);

	_pfnInMsgCallback = pfnCallback;
	_pThisClient = this;
	if (_pMqttClient->subscribe(pszSubscribeTopic))
	{
		SWIR_TRACE(F(">> MQTT Subscribe SENT"));
		rc = 0;
	}
	else
	{
		SWIR_TRACE(F(">> FAILED TO SENT MQTT Subscribe"));
	}

	free(pszSubscribeTopic);

	return rc;
}

void	SWIR_MQTTClient::setDebugPort(
					PORT_TYPE 		nRXport,
					PORT_TYPE 		nTXport,
					long 			nBaudrate)
{
	#ifdef _SWIR_OUTPUT_
	_tracer.setPort(nRXport, nTXport, nBaudrate);
	#endif
}

int SWIR_MQTTClient::getSignalQuality(int &nRssi, int &nBer, int &nEcLo)
{
	return 1;
	//return _swirModule.getSignalQuality(nRssi, nBer, nEcLo);
}



#define JSON_KEY_VAL_SEPARATOR	':'
#define JSON_KEY_VAL_END_MARKER	','
#define JSON_QUOTE				'\"'
#define JSON_OBJECT_START		'{'
#define JSON_OBJECT_END			'}'
#define JSON_ARRAY_START		'['
#define JSON_ARRAY_END			']'

char* SWIR_MQTTClient::getJsonValue(char* szJson, int nKeyIndex, char* szSearchKey)
{
	//use case 1 : nKeyIndex = -1 --> search by KeyName using szSearchKey as input
	//use case 2 : nKeyIndex > -1 --> search by index, szSearchKey, as output, will be filled with the keyName indexed by nIndexKey 
	char *	pszValue = NULL;

	char	cChar, cOpen, cClose;
	int		nState = 0, nPos = 0, nObjectCount = 0;
	int		nKeyNumber = -1;

	int		nKeyStartPos = -1, nKeyEndPos = -1;
	int 	nValStartPos = -1, nValEndPos = -1;

	do
	{
		cChar = szJson[nPos];

		switch (nState)
		{
			case 0:	//looks for open quote
			case 1: //looks for closing quote
				if (cChar == JSON_QUOTE)
				{
					//key : open and close quote
					if (nState == 0)
					{
						nKeyStartPos = nPos + 1;
					}
					else
					{
						nKeyEndPos = nPos - 1;
					}
					if (nKeyIndex==-1 && nState==1)
					{	//search with keyname
						if (nKeyStartPos > nKeyEndPos)
						{
							//no character in the quote/key/value
							nState = 0;	//skip this key/value, start over again and search for the next key
							break;
						}
						else if (0 != strncmp(szSearchKey, szJson+nKeyStartPos, nKeyEndPos - nKeyStartPos + 1))
						{
							nState = 0;	//skip this key/value, start over again and search for the next key
							break;
						}
					}
					nState++;
				}
				break;
			case 2:	//looks for separator, (only "white" spaces are allowed)
				if (cChar == JSON_KEY_VAL_SEPARATOR)
				{
					//found separator of value
					nState++;
					nValStartPos = nPos + 1;
				}
				else if (!isspace(cChar))
				{
					//error, unexpected character
					return pszValue;
				}
				break;
			case 3:	//detecting value starter
				if (cChar == JSON_QUOTE)
				{
					//found open quote of value
					nState = 4;
					nValStartPos = nPos + 1;
				}
				else if (cChar == JSON_KEY_VAL_END_MARKER)
				{
					//found end marker, no open quote. Case = "key" : xyz,
					nValEndPos = nPos - 1;
					nKeyNumber++;
					nState = -1;	//end search
				}
				else if (cChar == '\0')
				{
					//found end of string, no open quote. Case = "key" : xyz\0
					nValEndPos = nPos - 1;
					nKeyNumber++;
					nState = -1;	//end search
				}
				else if ((cChar == JSON_OBJECT_END) || (cChar == JSON_ARRAY_END))
				{
					//found end closing object/array, no open quote. Case = "key" : xyz}]
					nValEndPos = nPos - 1;
					nKeyNumber++;
					nState = -1;	//end search
				}
				else if ((cChar == JSON_OBJECT_START) || (cChar == JSON_ARRAY_START))
				{
					nState = 5;
					cOpen = cChar;
					cClose = (cChar == JSON_OBJECT_START ? JSON_OBJECT_END : JSON_ARRAY_END);
					nObjectCount = 1;
					nValStartPos = nPos + 1;
				}
				break;
			case 4:	//value started with a quote, now looks for ending quote
				if (cChar == JSON_QUOTE)
				{
					//found closing quote of the value. Case = "key" : "value"
					nValEndPos = nPos - 1;
					nKeyNumber++;
					nState = -1;	//end search
				}
				break;
			case 5: //value started with an object/array open marker, looks for closing marker
				if (cChar == cOpen)
				{
					nObjectCount++;
				}
				else if (cChar == cClose)
				{
					nObjectCount--;
					if (nObjectCount == 0)
					{
						//found closing quote of the value. Case = "key" : {...}
						nValEndPos = nPos - 1;
						nKeyNumber++;
						nState = -1;	//end search
					}
				}
				break;
			case -1:
				break;
		}

		int bFound = 0;

		if (nState == -1)
		{	
			//found key/value
			if (nKeyIndex == -1 && nKeyNumber > -1)
			{
				//search by KeyName
				bFound = 1;
			}
			else if (nKeyIndex > -1 && nKeyNumber == nKeyIndex)
			{
				//search by index
				bFound = 1;
			}
			nState = 0;	//ready for new search
		}

		if (bFound)
		{
			if (nValEndPos > nValStartPos)
			{
				int nLen = nValEndPos - nValStartPos + 1;
				pszValue = (char *) malloc(nLen + 1);
				memset(pszValue, 0, nLen + 1);
				memcpy(pszValue, szJson+nValStartPos, nLen);
			}
			else
			{
				pszValue = (char *) malloc(1);
				*pszValue = 0;
			}
			if (nKeyIndex > -1 && szSearchKey)
			{
				//return the KeyName
				memcpy(szSearchKey, szJson+nKeyStartPos, nKeyEndPos - nKeyStartPos + 1);
				szSearchKey[nKeyEndPos - nKeyStartPos + 1] = 0;
			}
			break;
		}

		nPos++;

	} while (nPos <= strlen(szJson));

	return pszValue;
}
