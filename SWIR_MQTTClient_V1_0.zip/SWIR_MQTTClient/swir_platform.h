/*
 * Definition for MQTT Client tailored for Sierra Wireless' HL Serie Modules and Sierra Wireless AirVantage
 *
 * Nhon Chu - May 2015
 */

#ifndef _SWIR_PLATFORM_H_
#define _SWIR_PLATFORM_H_

#include "swir_platform_def.h"


#ifdef TARGET_MBED
#include <mbed.h>
#include "Countdown_mbed.h"
#include <string>
#define DEBUG_SERIAL_CLASS                      Serial
#define MODULE_SERIAL_CLASS                     Serial
#define MODULE_SERIAL_OBJECT                    Serial
#define COUNTDOWN_CLASS							Countdown_mbed
#define GET_ELLAPSED_MS							time(NULL)
#define PORT_TYPE                               PinName
#define F(arg)                                  arg
#define SERIAL_SET_BAUD_RATE                    baud
#define SERIAL_READ_AVAILABLE                   readable
#define SERIAL_READ_CHAR                        getc
#define SERIAL_WRITELN_STRING(obj, arg)         obj->printf(arg); obj->printf("\r\n")
#define STRING_CLASS                            string
#define DELAY_MS                                wait_ms
#endif


#ifdef TARGET_ARDUINO
#include <SPI.h>
#include <SoftwareSerial.h>
#include "Countdown.h"
#define DEBUG_SERIAL_CLASS                      SoftwareSerial
#define MODULE_SERIAL_CLASS                     HardwareSerial
#define MODULE_SERIAL_OBJECT                    Serial1
#define COUNTDOWN_CLASS							Countdown
#define GET_ELLAPSED_MS							millis();
#define PORT_TYPE                               int
#define SERIAL_SET_BAUD_RATE                    begin
#define SERIAL_READ_AVAILABLE                   available
#define SERIAL_READ_CHAR                        read
#define SERIAL_WRITELN_STRING(obj, arg)         obj->println(arg)
#define STRING_CLASS                            String
#define DELAY_MS                                delay
#endif



#endif //_SWIR_PLATFORM_H_
