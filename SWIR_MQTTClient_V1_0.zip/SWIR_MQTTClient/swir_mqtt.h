/*******************************************************************************
 * MQTT class for Sierra Wireless' HL Serie Modules
 * wrapping a simple MQTT Client and a TCP AT-Command layer (exposing same interface as Arduino's Client/EthernetClient)
 *
 * Nhon Chu - April 2017 - V1.00
 *******************************************************************************/

#ifndef SWIR_MQTTCLIENT_H
#define SWIR_MQTTCLIENT_H

#include "swir_platform.h"

#include "swir_tcp_hl.h"

#include "swir_debug.h"

#include "PubSubClient.h"

//#define MAX_LENGTH1			64
//#define MAX_LENGTH2			256
//#define MAX_PAYLOAD_SIZE	256

class SWIR_MQTTClient
{
	public:
		typedef int (*inMessageHandler)(const char* szKey, const char* szValue, const char* szTimestamp);
		typedef void (*messageHandler)(char * topic, char* payload, uint16_t length);

		SWIR_MQTTClient(
					MODULE_SERIAL_CLASS&	module);
		
		void	setBaudRate(
					long 			nBaudrate);
					
		int		setSimPIN(
					int 			nPinCode = -1);
		int		isSimReady();
		int		setAPN(
					char*			szAPN,
					char*			szAPNlogin = NULL,
					char*			szAPNpassword = NULL);
		int		connect(
					char*			szPassword,				//IMEI is used as identifier
					uint16_t		ulKeepAlive = 30);  	//default keeplive, 30 seconds
		int		connect(
					char*			szIdentifier,
					char*			szPassword,
					uint16_t		uiKeepAlive = 30);
		int 	isDataCallReady();
		int 	getSignalQuality(
					int 			&nRssi,
					int 			&nBer,
					int 			&nEcLo);
		int		isConnected();
		void	disconnect();
		void	loop();
		/*
		void	setPublishQos(
					int 			nQoS);					//nQOS = 0, 1 or 2
		*/
		int 	publish(
					char*			szKey,
					char*			szValue);
		int		publish(
					char*			szKey,
					double			dValue);
		int		publish(
					char*			szKey,
					int 			nValue);
		int		publish(
					char*			szKey,
					unsigned long	ulValue);
		int		subscribe(
					inMessageHandler pfnHandler);

		void	setDebugPort(
					PORT_TYPE 		nRXport,
					PORT_TYPE 		nTXport,
					long 			nBaudrate);
					
		int 	publishAckCmd(
					const char* 	szUid,
					int 			nAck,
					char*			szMessage);
		
	protected:
		static void		incomingMessageHandler(
							char*		topic,
							char*		payload,
							uint16_t	length);
		static int		handleCallback(
							char* 	szPath,
							char* 	szKey,
							char* 	szValue,
							char* 	szTimestamp);
		static char* 	getJsonValue(
							char* 	szJson,
							int 	nKeyIndex,
							char*	szSearchKey);
		
		SWIR_TCP_HL													_swirModule;
		PubSubClient*												_pMqttClient;
		char*														_pszSubscribedTopic;
		char*														_pszPublishTopic;
		char*														_pszAckCmdTopic;
		//enum MQTT::QoS												_ePublishQoS;
		static SWIR_MQTTClient*										_pThisClient;
		
		static inMessageHandler										_pfnInMsgCallback;
		#ifdef _SWIR_OUTPUT_
		swirOutput													_tracer;
		#endif
};

#endif
