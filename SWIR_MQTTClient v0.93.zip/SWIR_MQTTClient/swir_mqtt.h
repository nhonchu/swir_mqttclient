/*******************************************************************************
 * MQTT class for Sierra Wireless' HL Serie Modules
 * wrapping Paho's MQTTClient and using TCP_HL layer (replacing the default ipstack)
 *
 * Nhon Chu - May 2015 - V0.92
 *******************************************************************************/

#ifndef SWIR_MQTTCLIENT_H
#define SWIR_MQTTCLIENT_H

#include "swir_platform.h"

#include "swir_tcp_hl.h"

#include "swir_debug.h"

//#define MAX_LENGTH1			64
//#define MAX_LENGTH2			256
#define MAX_PAYLOAD_SIZE	256

class SWIR_MQTTClient
{
	public:
		typedef int (*inMessageHandler)(const char* szKey, const char* szValue, const char* szTimestamp);
		typedef void (*messageHandler)(MQTT::MessageData&);

		SWIR_MQTTClient(
					MODULE_SERIAL_CLASS	&module);
		
		void	setBaudRate(
					long 			nBaudrate);
					
		int		setSimPIN(
					int 			nPinCode = -1);
		int		isSimReady();
		int		setAPN(
					char*			szAPN,
					char*			szAPNlogin = NULL,
					char*			szAPNpassword = NULL);
		int		connect(
					char*			szPassword,				//IMEI is used as identifier
					unsigned long	ulKeepAlive = 30);  	//default keeplive, 30 seconds
		int		connect(
					char*			szIdentifier,
					char*			szPassword,
					unsigned long	ulKeepAlive = 30);
		int 	isDataCallReady();
		int 	getSignalQuality(
					int 			&nRssi,
					int 			&nBer,
					int 			&nEcLo);
		int		isConnected();
		void	disconnect();
		void	loop();
		void	setPublishQos(
					int 			nQoS);					//nQOS = 0, 1 or 2
		int 	publish(
					char*			szKey,
					char*			szValue,
					unsigned long	ulTimestamp = 0);
		int		publish(
					char*			szKey,
					double			dValue,
					unsigned long	ulTimestamp = 0);
		int		publish(
					char*			szKey,
					int 			nValue,
					unsigned long	ulTimestamp = 0);
		int		publish(
					char*			szKey,
					unsigned long	ulValue,
					unsigned long	ulTimestamp = 0);
		int		subscribe(
					inMessageHandler pfnHandler);

		void	setDebugPort(
					PORT_TYPE 		nRXport,
					PORT_TYPE 		nTXport,
					long 			nBaudrate);
					
		int 	publishAckCmd(
					const char* 	szUid,
					int 			nAck,
					char*			szMessage);
		
	protected:
		static void		incomingMessageHandler(
							MQTT::MessageData&	md);
		static int		handleCallback(
							char* 	szPath,
							char* 	szKey,
							char* 	szValue,
							char* 	szTimestamp);
		
		SWIR_TCP_HL													_swirModule;
		MQTT::Client<SWIR_TCP_HL, COUNTDOWN_CLASS, MAX_PAYLOAD_SIZE, 1>*	_pMqttClient;
		char*														_pszSubscribedTopic;
		char*														_pszPublishTopic;
		char*														_pszAckCmdTopic;
		enum MQTT::QoS												_ePublishQoS;
		static SWIR_MQTTClient*										_pThisClient;
		
		static inMessageHandler										_pfnInMsgCallback;
		#ifdef _SWIR_OUTPUT_
		swirOutput													_tracer;
		#endif
};

#endif
